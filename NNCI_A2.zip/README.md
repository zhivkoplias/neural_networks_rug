# Minover

By Erik Zhivkoplias and Jeroen Overschie.

## Usage

Both a Python file and a Jupyter Notebook file are provided. Both contain the same code.

To run minover, run:

```shell
./minover.py
```

## About

University of Groningen (c) 2020